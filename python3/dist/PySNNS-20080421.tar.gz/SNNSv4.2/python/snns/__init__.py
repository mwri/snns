"""
This package contains the module "krui" which provides the SNNS kernel.
In the module "util" there is useful stuff like dictionaries with
textual representations of numbered types.
"""
